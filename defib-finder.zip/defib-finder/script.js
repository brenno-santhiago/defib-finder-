let desfibriladores = [];

function initMap() {
    // Localização: Montes Claros
    const montesClaros = { lat: -16.7353, lng: -43.8578 };

    // Criar o mapa
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: montesClaros,
    });

    // Função para carregar dados do JSON e listar na tabela e no mapa
    fetch('desfibriladores.json')
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao carregar o arquivo JSON');
            }
            return response.json();
        })
        .then(data => {
            desfibriladores = data;
            atualizarDesfibriladores(map);
        })
        .catch(error => console.error('Erro ao carregar dados:', error));
}

// Função para atualizar a lista de desfibriladores na tabela e no mapa
function atualizarDesfibriladores(map) {
    const tabela = document.getElementById('desfibriladores-tabela').getElementsByTagName('tbody')[0];
    tabela.innerHTML = ''; // Limpar tabela

    desfibriladores.forEach(desfibrilador => {
        // Adicionar linha na tabela
        const row = tabela.insertRow();
        row.insertCell(0).innerText = desfibrilador.nome;
        row.insertCell(1).innerText = desfibrilador.cidade;
        row.insertCell(2).innerText = desfibrilador.bairro;
        row.insertCell(3).innerText = desfibrilador.rua;
        row.insertCell(4).innerText = desfibrilador.numero;
        row.insertCell(5).innerText = desfibrilador.longitude;
        row.insertCell(6).innerText = desfibrilador.latitude;

        // Adicionar marcador no mapa
        new google.maps.Marker({
            position: { lat: parseFloat(desfibrilador.latitude), lng: parseFloat(desfibrilador.longitude) },
            map: map,
            title: desfibrilador.nome
        });
    });
}

// Função para lidar com o envio do formulário de cadastro
function handleFormSubmit(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value;
    const localizacao = document.getElementById('localizacao').value;
    const latitude = document.getElementById('latitude').value;
    const longitude = document.getElementById('longitude').value;
    const descricao = document.getElementById('descricao').value;

    const novoDesfibrilador = {
        id: desfibriladores.length + 1,
        nome: nome,
        cidade: localizacao, // Supondo que a localização seja a cidade
        bairro: localizacao, // Adicionar bairro para simplificação
        rua: localizacao, // Adicionar rua para simplificação
        numero: '', // Número não fornecido no formulário
        longitude: longitude,
        latitude: latitude,
        descricao: descricao
    };

    // Adicionar o novo desfibrilador à lista e atualizar a exibição
    desfibriladores.push(novoDesfibrilador);
    atualizarDesfibriladores(map);
}

// Chamar a função initMap quando a página carregar
window.onload = function() {
    initMap();

    // Adicionar evento de submit ao formulário de cadastro
    const form = document.getElementById('cadastroDesfibrilador');
    if (form) {
        form.addEventListener('submit', handleFormSubmit);
    }
};